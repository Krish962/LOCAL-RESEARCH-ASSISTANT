# Group 29 report source

Main document: `report.tex`.

Authors: Krish (22AG3AI07), Prajojeet Pradhan (22CE3AI15), Aaditya Saraf (22NA3AI40), Pranjul Shukla (22NA3AI42), IIT Kharagpur.

The report uses the official ICLR 2025 style and bibliography files. Formatting parameters are unchanged. The header identifies the course project rather than conference publication. `style_sources.json` records the style-file URLs and checksums.

## Compilation

The main document is compatible with pdfLaTeX and BibTeX, including an Overleaf project with `report.tex` as its main file.

```text
pdflatex report.tex
bibtex report
pdflatex report.tex
pdflatex report.tex
```

## Content

The report covers the complete application, its component integration, methods and recorded experiments. Its measures distinguish retrieval relevance, answer coverage, automated source-reference review and supplementary local Ragas judgments. The reported 78.6% is answer coverage; correctness is assessed separately.
